// Code goes here

angular.module('myApp', [])
  .directive('uppercase', function() {
    return {
      restrict: 'A',
      require: 'ngModel',
      link: uppercaseLink
    };

    function uppercaseLink(scope, element, attr, ngModelCtrl) {
      var oldValue = convert(scope.$eval(attr.uppercase));
      if(oldValue) {
        applyUppercase(element, ngModelCtrl);
      }
    }
  });

function convert(value) {
  return value === true || value === 'true' || value === undefined || value === null;
}

function applyUppercase(element, ngModelCtrl) {
  element.css('text-transform', 'uppercase');
  ngModelCtrl.$parsers.push(toUppercase);
  var original = scope.$eval(attr.ngModel).toUpperCase();
  ngModelCtrl.$setViewValue(original);
  ngModelCtrl.$render();
}

function unapplyUppercase(element, ngModelCtrl) {
  element.css('text-transform', '');
  var index = ngModelCtrl.$parsers.indexOf(toUppercase);
  if (index > -1) {
    ngModelCtrl.$parsers.splice(index, 1);
  }
}

function toUppercase(value) {
  if (value) {
    return value.toUpperCase();
  }
  return value;
}

// ###################
angular.module('myApp')
  .controller('Controller', Controller);

function Controller() {
  var self = this;
  self.greet = 'Hello World';
}